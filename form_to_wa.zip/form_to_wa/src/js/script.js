function sendToWa() {
   const url = `https://wa.me/6287753518802?text=${nama.value}, ${pesan.value}`
   window.open(url, "_blank")
   console.log(nama.value)
   console.log(pesan.value)
}